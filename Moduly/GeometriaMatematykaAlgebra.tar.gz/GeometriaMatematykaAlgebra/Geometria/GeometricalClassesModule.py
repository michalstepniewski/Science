import numpy as np

import match; from match import rmsd

# w miare uprzatniete, ale punkt to tak naprawde to samo co wektor!
#####################################################################################################################################################
#####################################################################################################################################################


class SetOf2_Vectors ( list ):

      def __init__ ( self, Vectors ):

          self. Vectors = [ ]

          for InputVector in Vectors:

              self.Vectors. append ( Vector ( InputVector  ) ) 
          
          return

#####################################################################################################################################################

      def VectorProduct ( self ): # ok since you can only compute cross product in 3D space, then the vectors would be 3D with Z = 0

          A_3D = self.Vectors [ 0 ]
          B_3D = self.Vectors [ 1 ]

#
          if len ( A_3D) == 2:

             A_3D. append ( 0.0 )

          if len ( B_3D ) == 2:

             B_3D. append ( 0.0 ) # extenstion to 2D, add 3rd dimension
#
          Cx = ( A_3D [ 1 ] * B_3D [ 2 ] ) - ( A_3D [ 2 ] * B_3D [ 1 ] )
          Cy = ( A_3D [ 0 ] * B_3D [ 2 ] ) - ( A_3D [ 2 ] * B_3D [ 0 ] )
          Cz = ( A_3D [ 0 ] * B_3D [ 1 ] ) - ( A_3D [ 1 ] * B_3D [ 0 ] )

          C  = [ Cx, Cy, Cz ] 

          return Vector (C)

#####################################################################################################################################################

      def Angle ( self ):

          self.Sin = self.VectorProduct ().Length () / ( self.Vectors [ 0 ]. Length () * self.Vectors [ 1 ]. Length () ) 
          self.Angle = asin ( self.Sin )

          return self.Angle

#####################################################################################################################################################

      def AngleDEG ( self ): # powinno byc w funkcjach matematycznych
          import math

          return ( (self.Angle()/(2*math.pi))*360 )

# contact pattern is easier than 

#####################################################################################################################################################
#####################################################################################################################################################
import math; from math import *; import sys;
sys.path.insert (0,  '/home/soutys/Science/HelixNsets/Program/Wersje/2013_06_20/Moduly/GeometriaMatematykaAlgebra/Matematyka' )

import functions_module; from functions_module import *;

class Vector ( list ):

      def Length ( self ):

          LengthSq = 0.0;

          for N in range ( len ( self ) ): LengthSq += self [ N ]**2

          return sqrt ( LengthSq )  

#####################################################################################################################################################

      def AngleToXAxis ( self ):

          XAxis = [ 1.0, 0.0 ]

          VectorProduct = SetOf2_Vectors ( [ self, XAxis ] ).VectorProduct ( )

          VectorProductLength = Vector3D ( VectorProduct ).Length ( ) 

          SinAngle = VectorProduct [ 2 ] / ( self.Length ( ) * 1 )   # 1 being X Axis unit vector length
# beceause vector is in form 0,0, X
# trzeva uwazac bo dlugosc tez powinna byc w 3D 

          if self [ 0 ] >= 0.0:

             Angle = asin ( SinAngle )

          elif self [ 0  ] <= 0.0:

               Angle = (math.pi/2) + ( ( math.pi/2 ) - asin ( SinAngle ) )


          return Angle

#####################################################################################################################################################

      def AngleToZAxis ( self ):

          ZAxis = [ 0.0, 0.0, 1.0 ]

          VectorProduct = SetOf2_Vectors ( [ self, ZAxis ] ).VectorProduct ( )

          VectorProductLength = Vector ( VectorProduct ).Length ( ) 

#          print VectorProductLength

          SinAngle = VectorProductLength / ( self.Length ( ) * 1 )   # 1 being Z Axis unit vector length
# beceause vector is in form 0,0, Z
# trzeva uwazac bo dlugosc tez powinna byc w 3D 

          if self [ 2 ] >= 0.0: # teraz sprawdzanie cwiartki :)

             Angle = asin ( SinAngle )

          elif self [ 2  ] <= 0.0:

               Angle = (math.pi/2) + ( ( math.pi/2 ) - asin ( SinAngle ) )


          return Angle

#####################################################################################################################################################

      def SmallestAngleToZAxis ( self ):

          ZAxis = [ 0.0, 0.0, 1.0 ]

          VectorProduct = SetOf2_Vectors ( [ ZAxis, self ] ).VectorProduct ( )



          VectorProductLength = Vector ( VectorProduct ).Length ( ) 
          print self
          print VectorProduct
          print self.Length ( )
          print 

          SinAngle = VectorProductLength / ( self.Length ( ) * 1.0 )   # 1 being Z Axis unit vector length
# beceause vector is in form 0,0, Z
# trzeva uwazac bo dlugosc tez powinna byc w 3D 

#          if self [ 2 ] >= 0.0: # teraz sprawdzanie cwiartki :)

          print SinAngle

          Angle = asin ( SinAngle )

#          elif self [ 2  ] <= 0.0:

#               Angle = (math.pi/2) + ( ( math.pi/2 ) - asin ( SinAngle ) )


#           if Angle >= (np.pi/2.0):
#              Angle = 

          return ( Angle/(2*np.pi) ) * 360

#####################################################################################################################################################
#####################################################################################################################################################

class Point ( list ):

      def Rotate ( self, RotationMatrix  ):
# poczytac w wikipedii, potem uogolnic

          Point1 = [ ]

          for I in range (  len ( self ) ):
              Coord = 0.0

              for J in range ( len ( self ) ):

                  Coord += RotationMatrix [I][J] * self [J]
              Point1. append ( Coord )

          return Point1

#####################################################################################################################################################

      def Translate ( self, Vector ):

          TranslatedPoint = [ ]

          for N in range ( len ( self ) ):
              
              TranslatedPoint. append ( self [ N ] + Vector [ N ] )

          return TranslatedPoint

#####################################################################################################################################################

      def RotateByAngle ( self, Angle ): # in 2D in XY plane

          RotationMatrix2D = Generate2DRotationMatrix ( Angle )
          
          Point1 = self.RotateByMatrix ( RotationMatrix2D )

          return Point1

#####################################################################################################################################################
#####################################################################################################################################################

class SetOfPoints ( list ):

      def __init__ ( self, InputPoints ):

          self. Content = [ Point ( InputPoint ) for InputPoint in InputPoints ] 

#####################################################################################################################################################


      def Vector ( self ):

          self.Vector = [ ]

          for N in range ( len ( self. Content [0] ) ):

              self.Vector. append ( self. Content [1][N] - self. Content [0][N] )  

          return Vector ( self.Vector )

#####################################################################################################################################################

      def PCAAxis ( self ):


          import numpy as np

          data = np.array( SetOfPointsI )
          datamean=data.mean(axis=0)
          uu, dd, vv = np.linalg.svd(data - datamean)
          PCAAxisI = vv[0]

          return PCAAxisI

#####################################################################################################################################################

      def Center ( self ):

          SumX, SumY, SumZ = [ 0.0, 0.0, 0.0 ]

          for PointI in self.Content:

              SumX += PointI [0]
              SumY += PointI [1]
              SumZ += PointI [2]

          No = float ( len ( self.Content ) )

          return [ SumX/No, SumY/No, SumZ/No ] 

#####################################################################################################################################################

      def Translate ( self, Vector ): #bedzie czeba to przebudowac

          return SetOfPoints ( [ Point. Translate ( Vector ) for Point in self. Content ] )            

#####################################################################################################################################################

      def TranslateToOrigin ( self ):

          VectorI = self.Center ( )

          
          return self. Translate ( [-VectorI[0],-VectorI[1],-VectorI[2] ] )

#####################################################################################################################################################

      def Array (self):

          ciag1 = [ ]

          for i in range ( len (self.Content ) ):

              for j in range ( len(self.Content[0]) ):

#                  print self.Content[i]

                  el1 = [ float (c) for c in self.Content[i] ]

                  ciag1. append ( el1 );

          return np.array(ciag1)

#####################################################################################################################################################
#####################################################################################################################################################

class SetsOfPoints ( list ):
# no i gdzie mialem te listy z flip RMSD itd
      def RMSD ( self ):

          ciag1 = []
          ciag2 = []

          for i in range ( len (self[0] ) ):

              for j in range ( len(self[0][0]) ):

                  el1 = [ float (c) for c in self[0][i][j] ]
                  el2 = [ float (c) for c in self[1][i][j] ]

                  ciag1. append ( el1 ); ciag2. append ( el2 );

          ciag1C = SetOfPoints ( ciag1 ). TranslateToOrigin (). Array ( );
          ciag2C = SetOfPoints ( ciag2 ). TranslateToOrigin ( ). Array ( ); 
          
#          print rmsd (np.array(ciag1), np.array(ciag2))
          return  rmsd (np.array(ciag1C), np.array(ciag2C)) # to bedzie z match.py

#####################################################################################################################################################

      def SuperpositionMatrix ( self, AllowPerturbations = False ):

          from match import optimal_superposition

          if AllowPerturbations:

             RMSDs = [ ]; Matrices = [ ];

             from Kombinatoryka import Perturbations

             minRMSD = 1000.0

             Centres1 = self[1] # bo to przeciez ten drugi, blargh

             for Perturbation in Perturbations( len ( self[1] ) ):

                 Centres1Perturbation = [ Centres1 [i] for i in Perturbation ]

                 ciag1, ciag2 = [ [], [] ]

                 for i in range ( len (self[0] ) ):

                     for j in range ( len(self[0][0]) ):

                         el1 = [ float (c) for c in self[0][i][j] ]
                         el2 = [ float (c) for c in Centres1Perturbation [i][j] ]

                         ciag1. append ( el1 ); ciag2. append ( el2 );
             
                 Matrices. append ( optimal_superposition ( np.array(ciag1), np.array(ciag2) ).T )
                 RMSDs. append ( rmsd (np.array(ciag1), np.array(ciag2))  )

             minRMSD = min ( RMSDs ); 

             return Matrices [ RMSDs. index ( minRMSD) ]


          else:

             ciag1, ciag2 = [ [], [] ]

             for i in range ( len (self[0] ) ):

                 for j in range ( len(self[0][0]) ):

                     el1 = [ float (c) for c in self[0][i][j] ]
                     el2 = [ float (c) for c in self[1][i][j] ]

                     ciag1. append ( el1 ); ciag2. append ( el2 );

          return optimal_superposition( np.array(ciag1), np.array(ciag2) ).T

# wiec niekoniecznie jest to dobry sposob, musze zrobic riport ktory bedzie porownywal efekt alajnu z perturbacjami i bez, musze tez pomyslec o moim sposobie klasyfikacji :)
#####################################################################################################################################################
# oprocz tego skonczyc perceptron, 3)
# movielensy, 4)
# grup riport 2)
# publikacja 1)
