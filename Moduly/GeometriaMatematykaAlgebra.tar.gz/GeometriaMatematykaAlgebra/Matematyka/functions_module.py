import sys, math
from math import *


###################################################

def Generate2DRotationMatrix ( Angle ): # angle counter-clockwise

    RotationMatrix2D = [ [ cos ( Angle ), - sin ( Angle ) ], \
                         [ sin ( Angle ),   cos ( Angle ) ] ]

#    print RotationMatrix2D

    return RotationMatrix2D

# orientation One Absolute Descriptor ( N ter, ) two Relative Ones (two other helices

###################################################

def BinarizeNat ( Nat ):

    if Nat == 0:
       return 0
    else: 
       return 1

#####################################################

 



