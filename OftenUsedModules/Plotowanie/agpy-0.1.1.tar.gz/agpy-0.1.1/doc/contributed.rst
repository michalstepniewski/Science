contributed Package
===================

:mod:`contributed` Package
--------------------------

.. automodule:: contributed
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`parallel_map` Module
--------------------------

.. automodule:: contributed.parallel_map
    :members:
    :undoc-members:
    :show-inheritance:

