.. automodule:: agpy.gaussfitter
    :members:

