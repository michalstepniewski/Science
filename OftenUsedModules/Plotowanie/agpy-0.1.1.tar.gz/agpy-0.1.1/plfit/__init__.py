#from plfit import discrete_likelihood
from plfit import plfit
from plfit import test_fitter,pl_inv,plexp_inv,plexp,plfit_lsq
from plfit_py import plfit as plfit_py
